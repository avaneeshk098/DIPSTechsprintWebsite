secret = input("Enter the passphrase:")
if secret[2] == 'S':
  if secret[6] == 'u':
    if secret[6] == 'u':
      if secret[0] == 'D':
        if secret[3] == '{':
          if secret[2] == 'S':
            if secret[12] == '}':
              if secret[1] == 'P':
                if secret[7] == '3':
                  if secret[5] == 'l':
                    if secret[4] == 'B':
                      if secret[2] == 'S':
                        if secret[8] == '_':
